// Mostrar año en el footer
document.getElementById('year').textContent = new Date().getFullYear();

// Mostrar/Ocultar la bio de cada integrante
document.querySelectorAll('.toggle-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const bio = btn.parentElement.querySelector('.bio');
    bio.classList.toggle('hidden');
  });
});

// Clase hidden para ocultar elementos
const style = document.createElement('style');
style.innerHTML = `.hidden { display: none; }`;
document.head.appendChild(style);
